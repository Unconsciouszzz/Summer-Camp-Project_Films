<?php
	require_once 'login.php';
	$link = mysqli_connect($host, $user, $password, $db);
	$right = -1;
	if (isset($_COOKIE['id']) and isset($_COOKIE['hash'])) {  
		$cook_id = $_COOKIE['id'];
		$query = "SELECT * FROM `user` WHERE `id` = '$cook_id'";
		$result = mysqli_query($link, $query);
		$row = mysqli_fetch_array($result, MYSQLI_ASSOC);
		if(($row['cookie'] != $_COOKIE['hash']) or ($row['id'] != $_COOKIE['id'])) {
	        setcookie("id", "", time() - 60 * 60 * 30 * 24 * 12, "/");
	        setcookie("hash", "", time() - 60 * 60 * 30 * 24 * 12, "/");
	    }
		else $right = $row['role'];
	}
	echo '
		<!DOCTYPE HTML>
		<html>
		<head>
			<link rel="stylesheet" href="my-bootstrap-2.css">
			<link rel="stylesheet" href="style5565.css"> 
			<link rel="stylesheet" href="st44.css">
			<meta name="description" content="Подборка сериалов, классифицированных по жанрам."/> 
			<meta name="keywords" content="сериалы tvshows shows tv description genres genre описание сериалов сериала сериалами ограничение женская мужская роль жанр режиссёр продолжительность 
			дата выход"/> 
			<meta charset="utf-8">
			<title>СЕРИАЛЫ</title>
			<script type = "text/javascript">
			function state(inp) {
				window.location = "Ievleva_base.php?genre=" + inp.value;
			}
		</script>
		</head>
		</html>
	';
	$name = $row['name'];
	$sur = $row['surname'];
	echo "<p></p>";
	echo '<nav class="navbar navbar-expand-lg navbar-light"  style= "background: #FFE1FF;">';
		echo '<form action = "Ievleva_main.php" method = "post">';
			if ($right == -1) {
				echo '<td><button name = "all" type = "submit" class = "button"><span><b>Авторизация</b></span></button></td>';
			}
			else {
				echo '<td><button name = "all" type = "submit" class = "button"><span><b>Выход из аккаунта</b></span></button></td>';
			}
		echo '</form>';
		if ($right == -1) {
			echo '<form action = "Ievleva_registration.php" method = "post">';
				echo '<td><button name = "all" type = "submit" class = "button"><span><b>Регистрация</b></span></button></td>';
			echo '</form>';
		}
		else {
			echo "<s3 style:'text-align=center;'}>Здравствуйте, ", $name, " ", $sur, "!</s3>";
		}
	echo '</nav>';
	echo "<p></p>";
	/*if ($right != -1) {
		echo "<td><s5>Здравствуйте, ", $name, " ", $sur, "!</s5></td>";
		echo "<form action = 'Ievleva_main.php' method = 'post'>";
			echo "<td><button name = 'all' type = 'submit' class = 'button'><span><b>Выйти из аккаунта</b></span></button></td>";
		echo "</form>";
	}
	if ($right == -1) {
		echo "<td><s5>Вы не зарегистрированы.</s5></td>";
		echo "<form action = 'Ievleva_main.php' method = 'post'>";
			echo "<td><button name = 'all' type = 'submit' class = 'button'><span><b>На главную</b></span></button></td>";
		echo "</form>";
	}*/
	echo '<div class="d2"><h3>', "СЕРИАЛЫ",'</h3></div>';
	echo '<p></p>';
	echo '<div class="d2"><h7>', "ВЫБЕРИТЕ ЖАНР:",'</h7></div>';
	echo '<p></p>';
	echo '<table style = "width: 40%">';
		echo '<tr><td>';
			echo '<form action="">';
				echo '<select name="genres" onChange = "state(this);" class="form-control form-control-sm">';
					echo '<option value="g0">Не выбрано</option>';
					if ($_GET['genre'] == "g1") echo '<option value="g2" selected>Комедия</option>';
					else echo '<option value="g1">Комедия</option>';
					if ($_GET['genre'] == "g2") echo '<option value="g1" selected>Драма</option>';
					else echo '<option value="g2">Драма</option>';
					if ($_GET['genre'] == "g3") echo '<option value="g3" selected>Триллер</option>';
					else echo '<option value="g3">Триллер</option>';
					if ($_GET['genre'] == "g4") echo '<option value="g4" selected>Фэнтези</option>';
					else echo '<option value="g4">Фэнтези</option>';
				echo '</select>';
			echo '</form>';
		echo '</tr></td>';
	echo '</table>';
	$gen = substr($_GET['genre'], 1);
	if ($gen != "0") $query = "SELECT * FROM `films` WHERE `films`.`Genre` = $gen";
	else $query = "SELECT * FROM `films`";
	$result = mysqli_query($link, $query);
	$i = 1;
	echo '<p></p>';
		echo '<p></p>';
		echo '<table>';
				echo '<tr>';
					echo '<th><s4><b>', "Постер", '</b></s4</th>';
					echo '<th><s4><b>', "Название", '</b></s4></th>';
					echo '<th><s4><b>',  "Дата выхода", '</b></s4></th>';
					echo '<th><s4><b>', "Главная мужская роль", '</b></s4></th>';
					echo '<th><s4><b>', "Главная женская роль", '</b></s4></th>';
					if ($right == 2) {
						echo '<th><s4><b>', "Редактирование", '</s4></b></th>';
						echo '<th><s4><b>', "Удаление", '</s4></b></th>';
					}
				echo '</tr>';
				while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
					$idX = $row['id'];
					$genre = $row['Genre'];
					$now = $row['id'];
					$img = $row['Poster'];
					$male = $row['Male'];
					$female = $row['Female'];
					$date = $row['Date'];
					$film = $row['Film'];
					
					if ($male == NULL) $male = "—";
					if ($female == NULL) $female = "—";
					if ($date == NULL) $date = "—";
					if ($film == NULL) $film = "—";
					echo "<tr >";
						echo "<form action = 'Ievleva_Chose.php?value=$idX' method = 'post'>";
							echo "<input type = 'hidden' name = 'id' value = '".$row['id']."'/>";
							echo "<td align=justify>", "<input alt='$film' type = 'image' width = 175 name = 'image' src='Фильмы/$img'>", "</td>";
						echo "</form>";
						echo "<form action = 'Ievleva_update.php?value=$idX' method = 'post'>";
							echo "<input type = 'hidden' name = 'id' value = '".$row['id']."'/>";
							echo "<td><s3><b>", $film, "</b></s3><input type = 'hidden' name = 'Film' value = '".$row['Film']."'/></td>";
							echo "<td><s3><b>", $date, "</b></s3><input type = 'hidden' name = 'Date' value = '".$row['Date']."'/></td>";
							echo "<td><s3><b>", $male, "</b></s3><input type = 'hidden' name = 'Male' value = '".$row['Male']."'/></td>";
							echo "<td><s3><b>", $female, "</b></s3><input type = 'hidden' name = 'Female' value = '".$row['Female']."'/></td>";
							echo "<input type = 'hidden' name = 'Poster1' value = '$img'/>";
							echo "<input type = 'hidden' name = 'Genre' value = '".$row['Genre']."'/>";
							echo "<input type = 'hidden' name = 'Country' value = '".$row['Country']."'/>";
							echo "<input type = 'hidden' name = 'Time' value = '".$row['Time']."'/>";
							echo "<input type = 'hidden' name = 'Director' value = '".$row['Director']."'/>";
							echo "<input type = 'hidden' name = 'AgeLimit' value = '".$row['AgeLimit']."'/>";
							echo "<input type = 'hidden' name = 'Description' value = '".$row['Description']."'/>";
							if ($right == 2) {
								echo "<td><button name = 'all' type = 'submit' class = 'button'><span><b>Update</b></span></button></td>";
							}
						echo "</form>";
						if ($right == 2) {
							echo "<form action = 'Ievleva_delete.php' method = 'post'>";
								echo "<input type = 'hidden' name = 'id' value = '".$row['id']."'/>";
								echo "<td><button name = 'all' type = 'submit' width = 15px class = 'button'><span><b>Delete</b></span></button></td>";
							echo "</form>";
						}
					echo "</tr>";
					$i++;
				}
		echo '</table>';
	if ($right == 2) {
		echo "<form action = 'Ievleva_insert.php' method = 'post'>";
			echo "<td><button name = 'all' type = 'submit' class = 'button'><span><b>Insert</b></span></button></td>";
		echo "</form>";
	}
	mysqli_free_result($result);
	mysqli_close($link);
?>
