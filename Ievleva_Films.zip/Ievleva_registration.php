<?php 
	require_once 'login.php';
	$link = mysqli_connect($host, $user, $password, $db);
	if (isset ($_POST['submit'])){
		$name = $_POST['Name'];
		$surname = $_POST['Surname'];
		$login = $_POST['Login'];
		$pass = $_POST['Password'];
		$pass = sha1(md5('good'.$pass.'omens'));
		$insert_sql = "INSERT INTO `user` (`id`, `login`, `hash`, `role`, `cookie`, `name`, `surname`)  VALUES  (NULL, '$login', '$pass', '1', '', '$name', '$surname')";
		$sql1 = mysqli_query($link, $insert_sql);
		header("Location:Ievleva_main.php");
	    mysqli_close($link);
	}
?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<link rel="stylesheet" href="st12.css">
	<meta charset="utf-8">
	<title>РЕГИСТРАЦИЯ</title>
</head>
<table>
	<p><div class="d2"><h3>РЕГИСТРАЦИЯ</h3></div></p>
	<form action="" method="post">
		<tr><td><input name="Name" size = "50" class="form-control" placeholder="Введите ваше имя"></td></tr>
		<tr><td><input size = "50" name="Surname" class="form-control" placeholder="Введите вашу фамилию"></td></tr>
		<tr><td><input size = "50" name="Login" class="form-control" placeholder="Придумайте логин"></td></tr>
		<tr><td><input size = "50" name="Password" type = "password" class="form-control" placeholder="Придумайте пароль"></td></tr>
		<tr><td><button name = 'submit' type = 'submit' class = 'button'><span><b>Зарегистрироваться</b></span></button></tr></td>
	</form>
	<p>
	<form action='Ievleva_main.php'>
		<button type = 'submit' class = 'button'><span><b>НА ГЛАВНУЮ</b></span></button>
	</form>
	</p>
</table>
</html>