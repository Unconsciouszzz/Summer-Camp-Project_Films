<?php 
	require_once 'login.php';
	$link = mysqli_connect($host, $user, $password, $db);
	setcookie('id', $id, time() - 60 * 60 * 30 * 24 * 12, "/");
	setcookie('hash', $rand, time() - 60 * 60 * 30 * 24 * 12, "/");
	if (isset ($_POST['submit'])){
		$login = $_POST['Login'];
		$pass = $_POST['Password'];
		$query = "SELECT * FROM `user` WHERE `login` = '$login'";
		$result = mysqli_query($link, $query);
		$row = mysqli_fetch_array($result, MYSQLI_ASSOC);
		if($row['hash'] == sha1(md5('good'.$pass.'omens'))) {
			$rand = substr(md5(microtime()), rand(0,26), 10);
			$id = $row['id'];
			$upd_sql = "UPDATE `user` SET `cookie` = '$rand' WHERE `id`='$id'";
			$sql = mysqli_query($link, $upd_sql);
			setcookie('id', $id, time() + 60 * 60 * 30 * 24 * 12);
			setcookie('hash', $rand, time() + 60 * 60 * 30 * 24 * 12);
			header("Location:Ievleva_base.php");
		}
	}
?>
<?php 
	require_once 'login.php';
	$link = mysqli_connect($host, $user, $password, $db);
	if (isset ($_POST['submit2'])){
		setcookie("id", "", time() - 60 * 60 * 30 * 24 * 12, "/");
	    setcookie("hash", "", time() - 60 * 60 * 30 * 24 * 12, "/");
		header("Location:Ievleva_base.php");
	}
?>
<!DOCTYPE html>
<table>
	<html>
	<head>
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
		<link rel="stylesheet" href="st12.css">
		<meta charset="utf-8">
		<title>ВХОД</title>
	</head>
	<body class = "div">
		<p><div class="d2"><h3>СЕРИАЛЫ</h3></div></p>
		<form action="" method="post">
			<button name = 'submit2' type = 'submit' class = 'button'><span><b>Вход без регистрации</b></span></button>
		</form>
		<p>
		<form action='Ievleva_registration.php'>
			<button name = 'all' type = 'submit' class = 'button'><span><b>Нет аккаунта? Регистрация</b></span></button>
		</form>
		</p>
		<form action="" method="post" >
				<div class="form-group">
					<tr><td><input size = "40" name="Login" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Введите ваш логин"></td></tr>
					<tr><td><input size = "40" type="password" name="Password" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Введите ваш пароль"></td></tr>
					<td><button name = 'submit' type = 'submit' class = 'button'><span><b>Вход</b></span></button></td>
				</div>
		</form>
	</body>
</table>
</html>