<?php 
	require_once 'login.php';
	$link = mysqli_connect($host, $user, $password, $db);
	$right = -1;
	if (isset($_COOKIE['id']) and isset($_COOKIE['hash'])) {  
		$cook_id = $_COOKIE['id'];
		$queryC = "SELECT * FROM `user` WHERE `id` = '$cook_id'";
		$resultC = mysqli_query($link, $queryC);
		$rowC = mysqli_fetch_array($resultC, MYSQLI_ASSOC);
		if(($rowC['cookie'] != $_COOKIE['hash']) or ($rowC['id'] != $_COOKIE['id'])) {
	        setcookie("id", "", time() - 60 * 60 * 30 * 24 * 12, "/");
	        setcookie("hash", "", time() - 60 * 60 * 30 * 24 * 12, "/");
			header("Location:Ievleva_base.php");
	    }
		else $right = $rowC['role'];
	}
?>
<!DOCTYPE html>
<?php 
	if ($right == 2) {
		require_once 'login.php';
		$link = mysqli_connect($host, $user, $password, $db);
		echo "<p><div class='d2'><h3>Редактирование сериала</h3></div></p>";
		echo $img;
		echo "<form action = 'Ievleva_base.php' method = 'post'>";
			echo "<button type = 'submit' class = 'button'><span><b>Назад</b></span></button>";
		echo "</form>";
		if (isset ($_POST['submit'])){
			if (mysqli_connect_errno()) {
				printf("Не удалось подключиться: %s\n", mysqli_connect_error());
				exit();
			}
			if (!$link->set_charset("utf8")) {
				printf("Ошибка при загрузке набора символов utf8: %s\n", $link->error);
			}
			$r = $_POST['id'];
			$film = $_POST['Film'];
			$date = $_POST['Date'];
			$male = $_POST['Male'];
			$female = $_POST['Female'];
			$poster = $_FILES['Poster'];
			$poster1 = $_POST['Poster1'];
			$genre = $_POST['Genre'];
			if ($genre == NULL) $genre = 0;
			$director = $_POST['Director'];
			$country = $_POST['Country'];
			$time = $_POST['Time'];
			$age = $_POST['AgeLimit'];
			$des = $_POST['Description'];
			if ($poster['name'] != "") {
				$poster1 = $poster['name'];
				move_uploaded_file($poster['tmp_name'], 'Фильмы/'.$poster['name']);
			}
			$insert_sql = "UPDATE Films SET  `Film` = '$film', `Date` = '$date', `Male` = '$male', `Female` = '$female', `Poster` = '$poster1', `Genre` = '$genre', `Director` = '$director', `Country` = '$country', `Time` = '$time', `AgeLimit` = '$age', `Description` = '$des' WHERE `id` = '$r'";
			$sql = mysqli_query($link, $insert_sql);
			if ($sql) {
				echo '<p><s5>Данные успешно редактированы.</s5></p>';
			} else {
				echo '<p><s5>Произошла ошибка: '.mysqli_error($link).'</s5></p>';
			}
			//mysqli_free_result($sql);
			mysqli_close($link);
		}
	}

?>
<html>
<head>
	<link rel="stylesheet" href="my-bootstrap-2.css">
	<link rel="stylesheet" href="st12.css">
	<meta charset="utf-8">
	<title>Редактирование</title>
</head>
<body>
<?php
	require_once 'login.php';
	$link = mysqli_connect($host, $user, $password, $db);
	$idX = $_GET['value'];
	$f = mysqli_fetch_assoc(mysqli_query($link, "SELECT * FROM `films` WHERE `id` = '$idX'"));
	echo "<form action='' method='post' enctype = 'multipart/form-data'>";
		echo "<table>";
			echo '<div class="form-group">';
				echo "<input type = 'hidden' size='50' name='id' value = '".$_POST['id']."'>";
				echo "<tr>
					<td size='20'><s6>Название:</s6></td>
					<td><input size='30' class='form-control' name='Film' placeholder='Введите название сериала' value = '".$_POST['Film']."'></td>
				</tr>";
				echo "<tr>
					<td size='20'><s6>Дата:</s6></td>
					<td><input size='30' class='form-control' name='Date' placeholder='Введите дату в формате ДД.ММ.ГГГГ' value = '".$_POST['Date']."'></td>
				</tr>";
				echo "<tr>
					<td size='20'><s6>Актёр:</s6></td>
					<td><input size='30' class='form-control' name='Male' placeholder='Введите имя актёра' value = '".$_POST['Male']."'></td>
				</tr>";
				echo "<tr>
					<td size='20'><s6>Актриса:</s6></td>
					<td><input size='30' class='form-control' name='Female' placeholder='Введите имя актрисы' value = '".$_POST['Female']."'></td>
				</tr>";
				echo '<tr>
					<td size="20"><s6>Жанр:</s6></td>
					<td>
					<form action="" method="post">
						<select name="Genre" class="form-control form-control-sm">';
							if ($f['Genre'] == 0) echo '<option value="0" selected>Не выбрано</option>';
							else echo '<option value="0">Не выбрано</option>';
							if ($f['Genre'] == 1) echo '<option value="1" selected>Комедия</option>';
							else echo '<option value="1">Комедия</option>';
							if ($f['Genre'] == 2) echo '<option value="2" selected>Драма</option>';
							else echo '<option value="2">Драма</option>';
							if ($f['Genre'] == 3) echo '<option value="3" selected>Триллер</option>';
							else echo '<option value="3">Триллер</option>';
							if ($f['Genre'] == 4) echo '<option value="4" selected>Триллер</option>';
							else echo '<option value="4">Триллер</option>';
						echo '</select>
					</form>
					</td>
				</tr>';
				echo "<tr>
					<td size='20'><s6>Режиссёр:</s6></td>
					<td><input size='30' class='form-control' name='Director' placeholder='Введите имя режиссёра' value = '".$_POST['Director']."'></td>
				</tr>";
				echo "<tr>
					<td size='20'><s6>Страна:</s6></td>
					<td><input size='30' class='form-control' name='Country' placeholder='Введите страну' value = '".$_POST['Country']."'></td>
				</tr>";
				echo "<tr>
					<td size='20'><s6>Продолжительность:</s6></td>
					<td><input size='30' class='form-control' name='Time' placeholder='Введите продолжительность' value = '".$_POST['Time']."'></td>
				</tr>";
				echo "<tr>
					<td size='20'><s6>Возрастное ограничение:</s6></td>
					<td><input size='30' class='form-control' name='AgeLimit' placeholder='Введите возрастное ограничение' value = '".$_POST['AgeLimit']."'></td>
				</tr>";
				echo "<tr>
					<td size='20'><s6>Описание:</s6></td>
					<td><textarea id='editor' name='Description' style = 'resize: none; width: 550px; height: 200px;' name = 'comment'>".$_POST['Description']."</textarea></td>
				</tr>";
				$img = $f['Poster'];
				echo "<tr>";
					echo "<td size='20'><s6>Текущий постер:</s6></td>";
					echo "<td>", "<img src='Фильмы/$img'>", "</td>";
				echo "</tr>";
				echo "<input type = 'hidden' size='30' name='Poster1' value = '$img'>";
				echo "<tr>
					<td size='20'><s6>Выбрать новый постер:</s6></td>
					<td><input type='file' class='form-control-file form-control-sm' id='exampleFormControlFile1' name='Poster' value = '".$_POST['Poster']."' multiple accept='image/*,image/jpeg'></td>
				</tr>";
				echo "<td colspan='2'><button name = 'submit' type = 'submit' class = 'button'><span><b>Update</b></span></button></td>";
			echo '</div>';
		echo "</table>";
	echo "</form>"
?>
</body>
</html>