<?php 
	require_once 'login.php';
	$link = mysqli_connect($host, $user, $password, $db);
	$right = -1;
	if (isset($_COOKIE['id']) and isset($_COOKIE['hash'])) {  
		$cook_id = $_COOKIE['id'];
		$queryC = "SELECT * FROM `user` WHERE `id` = '$cook_id'";
		$resultC = mysqli_query($link, $queryC);
		$rowC = mysqli_fetch_array($resultC, MYSQLI_ASSOC);
		if(($rowC['cookie'] != $_COOKIE['hash']) or ($rowC['id'] != $_COOKIE['id'])) {
	        setcookie("id", "", time() - 60 * 60 * 30 * 24 * 12, "/");
	        setcookie("hash", "", time() - 60 * 60 * 30 * 24 * 12, "/");
			header("Location:Ievleva_base.php");
	    }
		else $right = $rowC['role'];
	}
?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="my-bootstrap-2.css">
	<link rel="stylesheet" href="st12.css">
	<link rel="stylesheet" href="st44.css">
	<meta charset="utf-8">
	<title>Вставка записи</title>
</head>
<body>
<?php 
	if ($right == 2) {
		require_once 'login.php';
		$link = mysqli_connect($host, $user, $password, $db);
		echo "<p><div class='d2'><h3>Вставка нового сериала</h3></div></p>";
		echo "<form action = 'Ievleva_base.php' method = 'post'>";
			echo "<button type = 'submit' class = 'button'><span><b>Назад</b></span></button>";
		echo "</form>";
		if (isset ($_POST['submit'])){
			if (mysqli_connect_errno()) {
				printf("Не удалось подключиться: %s\n", mysqli_connect_error());
				exit();
			}
			if (!$link->set_charset("utf8")) {
				printf("Ошибка при загрузке набора символов utf8: %s\n", $link->error);
			}
			$film = $_POST['Film'];
			$date = $_POST['Date'];
			$male = $_POST['Male'];
			$female = $_POST['Female'];
			$poster = $_FILES['Poster'];
			$genre = $_POST['Genre'];
			if ($genre == NULL) $genre = 0;
			$director = $_POST['Director'];
			$country = $_POST['Country'];
			$time = $_POST['Time'];
			$age = $_POST['AgeLimit'];
			$des = $_POST['Description'];
			if ($poster['name'] == "") $post = "Постер.jpg";
			else {
				$post = $poster['name'];
				move_uploaded_file($poster['tmp_name'], 'Фильмы/'.$poster['name']);
			}
			$insert_sql = "INSERT INTO `Films` (`id`, `Film`, `Date`, `Male`, `Female`, `Poster`, `Genre`, `Director`, `Country`, `Time`, `AgeLimit`, `Description`)  VALUES  (NULL, '$film', '$date', '$male', '$female', '$post', '$genre', '$director', '$country', '$time', '$age', '$des')";
			$sql = mysqli_query($link, $insert_sql);
			if ($sql) {
				echo '<p><s5>Данные успешно добавлены в таблицу.</s5></p>';
			} else {
				echo '<p><s5>Произошла ошибка: '.mysqli_error($link).'</s5></p>';
			}
			//mysqli_free_result($sql);
			mysqli_close($link);
		}
	}

?>
<table>
	<div class="form-group">
		<form action="" method="post" enctype = "multipart/form-data">
				<tr>
					<td size="20"><s6>Название:</s6></td>
					<td><input class='form-control' size="30" name="Film" placeholder="Введите название"></td>
				</tr>
				<tr>
					<td size="20"><s6>Дата:</s6></td>
					<td><input class='form-control' size="30" name="Date" placeholder="Введите дату в формате ДД.ММ.ГГГГ"></td>
				</tr>
				<tr>
					<td size="20"><s6>Актёр:</s6></td>
					<td><input class='form-control' size="30" name="Male" placeholder="Введите имя актёра"></td>
				</tr>
				<tr>
					<td size="20"><s6>Актриса:</s6></td>
					<td><input class='form-control' size="30" name="Female" placeholder="Введите имя актрисы"></td>
				</tr>
				<tr>
					<td size="20"><s6>Жанр:</s6></td>
					<td>
					<select name="Genre" onChange = "state(this);" class="form-control form-control-sm">
						<option value="0">Не выбрано</option>
						<option value="1">Комедия</option>
						<option value="2">Драма</option>
						<option value="3">Триллер</option>
						<option value="4">Фэнтези</option>
					</select>
					</td>
				</tr>
				<tr>
					<td size="20"><s6>Режиссёр:</s6></td>
					<td><input class='form-control' size="30" name="Director" placeholder="Введите имя режиссёра"></td>
				</tr>
				<tr>
					<td size="20"><s6>Страна:</s6></td>
					<td><input class='form-control' size="30" name="Country" placeholder="Введите страну"></td>
				</tr>
				<tr>
					<td size="20"><s6>Продолжительность:</s6></td>
					<td><input class='form-control' size="30" name="Time" placeholder="Введите продолжительность"></td>
				</tr>
				<tr>
					<td size="20"><s6>Возраст:</s6></td>
					<td><input class='form-control' size="30" name="AgeLimit" placeholder="Введите возрастное ограничение"></td>
				</tr>
				<tr>
					<td size="20"><s6>Описание:</s6></td>
					<td><textarea id='editor' name='Description' style = 'resize: none; width: 550px; height: 200px;' name = 'comment'></textarea></td>
				</tr>
				<tr>
					<td size="20"><s6>Постер:</s6></td>
					<td><input class='form-control-file form-control-sm' type="file" name="Poster" src="Постер.jpg"></td>
				</tr>
				<td colspan="2"><button name = "submit" type = "submit" class = 'button'><span><b>Insert</b></span></button></td>
		</form>
	</div>
</table>
</body>
</html>