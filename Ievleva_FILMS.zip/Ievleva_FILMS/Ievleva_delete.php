<?php 
	require_once 'login.php';
	$link = mysqli_connect($host, $user, $password, $db);
	$right = -1;
	if (isset($_COOKIE['id']) and isset($_COOKIE['hash'])) {  
		$cook_id = $_COOKIE['id'];
		$queryC = "SELECT * FROM `user` WHERE `id` = '$cook_id'";
		$resultC = mysqli_query($link, $queryC);
		$rowC = mysqli_fetch_array($resultC, MYSQLI_ASSOC);
		if(($rowC['cookie'] != $_COOKIE['hash']) or ($rowC['id'] != $_COOKIE['id'])) {
	        setcookie("id", "", time() - 60 * 60 * 30 * 24 * 12, "/");
	        setcookie("hash", "", time() - 60 * 60 * 30 * 24 * 12, "/");
			header("Location:Ievleva_base.php");
	    }
		else $right = $rowC['role'];
	}
?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="my-bootstrap-2.css">
	<link rel="stylesheet" href="style5565.css">
	<link rel="stylesheet" href="st44.css">
	<meta charset="utf-8">
	<title>Удаление записи</title>
</head>
<body>
<?php
	if ($right == 2) {
		require_once 'login.php';
		$link = mysqli_connect($host, $user, $password, $db);
		echo "<p><div class='d2'><h3>Удаление сериала</h3></div></p>";
		if (isset ($_POST['id'])){
			if (mysqli_connect_errno()) {
				printf("Не удалось подключиться: %s\n", mysqli_connect_error());
				exit();
			}
			if (!$link->set_charset("utf8")) {
				printf("Ошибка при загрузке набора символов utf8: %s\n", $link->error);
			}
			$r = $_POST['id'];
			$query ="DELETE FROM `Films` WHERE id = '$r'";
			$result = mysqli_query($link, $query);
			if ($result) {
				echo "<p><s5>Данные успешно удалены из таблицы.</s5></p>";
			} else {
				echo '<p><s5>Произошла ошибка: '.mysqli_error($link).' </s5></p>';
			}
			echo "<form action='Ievleva_base.php'>";
				echo "<td><button name = 'all' type = 'submit' class = 'button'><span><b>К результатам</b></span></button></td>";
			echo "</form>";
		}
	}
?>
</body>
</html>