<?php 
	require_once 'login.php';
	$link = mysqli_connect($host, $user, $password, $db);
	$right = -1;
	if (isset($_COOKIE['id']) and isset($_COOKIE['hash'])) {  
		$cook_id = $_COOKIE['id'];
		$queryC = "SELECT * FROM `user` WHERE `id` = '$cook_id'";
		$resultC = mysqli_query($link, $queryC);
		$rowC = mysqli_fetch_array($resultC, MYSQLI_ASSOC);
		if(($rowC['cookie'] != $_COOKIE['hash']) or ($rowC['id'] != $_COOKIE['id'])) {
	        setcookie("id", "", time() - 60 * 60 * 30 * 24 * 12, "/");
	        setcookie("hash", "", time() - 60 * 60 * 30 * 24 * 12, "/");
	    }
		else $right = $rowC['role'];
	}
?>
<?php 
	$idE = $_GET['value'];
	$queryE ="SELECT * FROM `films` WHERE id = $idE";
	$resultE = mysqli_query($link, $queryE);
	$rowE = mysqli_fetch_array($resultE, MYSQLI_ASSOC);
	$FE = $rowE['Film'];
	echo '
		<!DOCTYPE html>
		<html>
		<head>
			<meta name="description" content="Подборка сериалов, классифицированных по жанрам."/> 
			<meta name="keywords" content="'.$rowE['Film'].' '.$rowE['Poster'].' '.$rowE['Male'].' '.$rowE['Female'].' '.$rowE['Director'].' '.$rowE['Country'].'"/> 
			<link rel="stylesheet" href="my-bootstrap-2.css">
			<link rel="stylesheet" href="st663.css">
			<link rel="stylesheet" href="st44.css">
			<meta charset="utf-8">
			<title>'.$FE.'</title>
		</head>
	';
?>
	<body class = "bg2">
		<?php
			$id = $_GET['value'];
			$query ="SELECT * FROM `films` WHERE id = $id";
			$result = mysqli_query($link, $query);
			$row = mysqli_fetch_array($result, MYSQLI_ASSOC);
			$idG = $row['Genre'];
			$query1 = "SELECT * FROM `genre` WHERE `id` = '$idG'";
			$result1 = mysqli_query($link, $query1);
			$row1 = mysqli_fetch_array($result1, MYSQLI_ASSOC);
			$nameG = $row1['Genre'];
			echo "<form action = 'Ievleva_base.php' method = 'post'>";
				echo "<button type = 'submit' class = 'button'><span><b>Назад</b></span></button>";
			echo "</form>";
			echo "<p></p>";
			$name = $rowC['name'];
			$sur = $rowC['sur'];
			$img = $row['Poster'];
			$fil = $row['Film'];
			echo '<div class="d2"><h3>', $row['Film'],'</h3></div>';
			echo "<p></p>";
			echo '<table>';
				$dirT = $row['Director'];
				$maleT = $row['Male'];
				$femaleT = $row['Female'];
				$dateT = $row['Date'];
				$ageT = $row['AgeLimit'];
				$timeT = $row['Time'];
				$coT = $row['Country'];
				if ($maleT == NULL) $maleT = "—";
				if ($femaleT == NULL) $femaleT = "—";
				if ($dateT == NULL) $dateT = "—";
				if ($dirT == NULL) $dirT = "—";
				if ($ageT == NULL) $ageT = "—";
				if ($timeT == NULL) $timeT = "—";
				if ($coT == NULL) $coT = "—";
				if ($nameG == NULL) $nameG = "—";
				echo '<tr>';
					echo "<td rowspan = 8 align=justify><s3>", "<p margin='auto'><img alt='$fil' align=justify style='width: 100%; height: 100%;' src='Фильмы/$img'></p>", "</s3></td>";
					echo '<td><s3><b class="font-weight-bold"> Дата выхода: </b>', $dateT, '</s3></td>';
				echo '</tr>';
				echo '<tr><td><s3><b class="font-weight-bold"> Главная мужская роль: </b>', $maleT, '</s3></td></tr>';
				echo '<tr><td><s3><b class="font-weight-bold"> Главная женская роль: </b>', $femaleT, '</s3></td></tr>';
				echo '<tr><td><s3><b class="font-weight-bold"> Режиссёр: </b>', $dirT, '</s3></td></tr>';
				echo '<tr><td><s3><b class="font-weight-bold"> Жанр: </b>', $nameG, '</s3></td></tr>';
				echo '<tr><td><s3><b class="font-weight-bold"> Страна: </b>', $coT, '</s3></td></tr>';
				echo '<tr><td><s3><b class="font-weight-bold"> Возрастное ограничение: </b>', $ageT, '</s3></td></tr>';
				echo '<tr><td><s3><b class="font-weight-bold"> Продолжительность: </b>', $timeT, '</s3></td></tr>';
				echo '<td colspan = 2><s3><b class="font-weight-bold"> Описание: </b>', $row['Description'], '</s3></td>';
			echo "</table>";
			echo "<p></p>";
			echo "<p></p>";
			echo "<div class='header-h1 header-h1-center'>";
				echo "<h1>РЕЦЕНЗИИ НА ФИЛЬМ</h1>";
			echo "</div>";
			if ($right > -1){
				echo'<form action = "#" method = "POST">
					<table>
						<tr><td>
							<textarea id="editor" style = "resize: none; width: 850px; height: 200px;" name = "comment"></textarea>
						</td></tr>
					</table>
					<td><button name = "klik" type = "submit" class = "button"><span><b>Отправить</b></span></button></td>
				</form>';
			}
			else {
				echo "<form action = 'Ievleva_main.php' method = 'post'>";
					echo "<button type = 'submit' class = 'button'><span><b>Зарегистрируйтесь для написания рецензии</b></span></button>";
				echo "</form>";
			}
			if (isset ($_POST['klik'])){ 
				$com = nl2br($_POST['comment']);
				$time = time();
				$insert_sql = "INSERT INTO `comments` (`id`, `userid`, `filmid`, `time`, `comment`)  VALUES  (NULL, '$cook_id', '$id', '$time', '$com')";
				$sql = mysqli_query($link, $insert_sql);
				echo'<meta http-equiv="refresh" content="0">';
			}
			$queryX ="SELECT * FROM `comments` WHERE `filmid` = $id ORDER BY `time` DESC";
			$resultX = mysqli_query($link, $queryX);
			while ($rowX = mysqli_fetch_array($resultX, MYSQLI_ASSOC)) {
				$userid = $rowX['userid'];
				$queryP ="SELECT * FROM `user` WHERE `id` = $userid";
				$resultP = mysqli_query($link, $queryP);
				$rowP = mysqli_fetch_array($resultP, MYSQLI_ASSOC);
				$log = $rowP['login'];
				$com = $rowX['comment'];
				echo "<p>";
					echo "<table style = 'width: 700px'>";
						echo "<tr>";
							echo "<td><s3><b class='font-weight-bold'>Автор: </b>", "$log", "</s3></td>";
							echo "<td><s3><b class='font-weight-bold'>Дата: </b>", date('d.m.Y', $rowX['time']), "</s3></td>";
							echo "<td><s3><b class='font-weight-bold'>Время: </b>";
							if(($rowX['time'] / 60 / 60 % 24 + 3) < 10) echo "0";
							echo $rowX['time'] / 60 / 60 % 24 + 3, ":";
							if(($rowX['time'] / 60 % 60) < 10) echo "0";
							echo $rowX['time'] / 60 % 60, ":";
							if(($rowX['time'] % 60) < 10) echo "0";
							echo $rowX['time'] % 60, "</s3></td>";
						echo "</tr>";
						echo "<td colspan = 3 class='text-break'><s3>$com<s3></td>";
					echo "</table>";
				echo "</p>";
			}
		?>
	</body>
</html>