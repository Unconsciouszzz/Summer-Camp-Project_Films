<?php
	$host = 'localhost';
	$user = 'root';
	$password = '';
	$db = 'Films';
?>